Use the 512px PNG for the store listing with Toolinger 4.5.0. The SVG embeds PNG artwork rather than editable vector paths.
