Use the 512px PNG with Toolinger 4.6.0 for Indus. The SVG embeds raster PNG; it is not an editable vector drawing.
